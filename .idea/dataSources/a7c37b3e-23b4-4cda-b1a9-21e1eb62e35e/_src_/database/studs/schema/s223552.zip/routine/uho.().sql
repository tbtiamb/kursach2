create function uho() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
IF(NEW.НАЗВАНИЕ LIKE '%семейство%' OR NEW.НАЗВАНИЕ LIKE '%семья%') THEN
INSERT INTO ИЕРАРХИЯ(ЭЛЕМЕНТ, ПРЕДОК, УРОВЕНЬ)
VALUES(NEW.ИД_ЭЛЕМЕНТА, NULL, 1);
ELSIF(NEW.НАЗВАНИЕ LIKE '%ветвь%') THEN
INSERT INTO ИЕРАРХИЯ(ЭЛЕМЕНТ, ПРЕДОК, УРОВЕНЬ)
VALUES(NEW.ИД_ЭЛЕМЕНТА, NULL, 2);
ELSIF(NEW.НАЗВАНИЕ LIKE '%группа%') THEN
INSERT INTO ИЕРАРХИЯ(ЭЛЕМЕНТ, ПРЕДОК, УРОВЕНЬ)
VALUES(NEW.ИД_ЭЛЕМЕНТА, NULL, 3);
ELSIF(NEW.НАЗВАНИЕ LIKE '%язык%') THEN
INSERT INTO ИЕРАРХИЯ(ЭЛЕМЕНТ, ПРЕДОК, УРОВЕНЬ)
VALUES(NEW.ИД_ЭЛЕМЕНТА, NULL, 4);
ELSE
INSERT INTO ИЕРАРХИЯ(ЭЛЕМЕНТ, ПРЕДОК, УРОВЕНЬ)
VALUES(NEW.ИД_ЭЛЕМЕНТА, NULL, 4);
END IF;
RETURN NEW;
END;
$$;
