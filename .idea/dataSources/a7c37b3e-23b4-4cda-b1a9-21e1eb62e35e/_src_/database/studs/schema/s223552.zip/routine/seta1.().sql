create function seta1() returns integer
LANGUAGE plpgsql
AS $$
DECLARE

i INTEGER;


begin


i := 1;
while i <> 220000 loop
INSERT INTO A(ВИД)
VALUES('LOL');
i := i+1;
end loop;
RETURN 1;
end;
$$;
