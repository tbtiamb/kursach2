create function deadoralive() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
IF(NEW.СОСТОЯНИЕ = FALSE) THEN
UPDATE ЭЛЕМЕНТ SET ЧИСЛО_ГОВОРЯЩИХ = 0 
WHERE ИД_ЭЛЕМЕНТА = NEW.ИД_ЭЛЕМЕНТА;
ELSIF(NEW.ЧИСЛО_ГОВОРЯЩИХ = 0) THEN
UPDATE ЭЛЕМЕНТ SET СОСТОЯНИЕ = FALSE
WHERE ИД_ЭЛЕМЕНТА = NEW.ИД_ЭЛЕМЕНТА; 
END IF;
RETURN NEW;
END;
$$;
